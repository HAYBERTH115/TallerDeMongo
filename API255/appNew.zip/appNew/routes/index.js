const routerComments = require('./routesComments');
const routerMovies = require('./routesMovies');
const routerSessions = require('./routesSessions');
const routerTheaters = require('./routesTheaters');
const routerUsers = require('./routesUsers');

function routerApi(app){
    app.use('/comments', routerComments);//La app que creamos con appexpress va a asociar "movies" con el controlador routesMovies
    app.use('/movies', routerMovies);
    app.use('/sessions', routerSessions);
    app.use('/theaters', routerTheaters);
    app.use('/users', routerUsers);
}

module.exports = routerApi;